import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// English translations
const enTranslations = {
  navigation: {
    home: "HOME",
    services: "SERVICES",
    creators: "CREATORS",
    about: "ABOUT US",
    contact: "CONTACT"
  },
  hero: {
    heading1: "ELEVATE YOUR",
    heading2: "STREAMING",
    heading3: "CAREER",
    description: "Join the elite network of content creators and streamers. We help you grow, connect and monetize your passion.",
    joinButton: "JOIN OUR TEAM",
    servicesButton: "OUR SERVICES",
    discoverMore: "Discover More"
  },
  services: {
    title: "OUR SERVICES",
    description: "Comprehensive solutions for content creators and streamers at every stage of their career.",
    items: [
      {
        title: "Growth Strategy",
        description: "Customized plans to increase your followers, viewers and engagement across all platforms.",
        learnMore: "Learn more"
      },
      {
        title: "Brand Partnerships",
        description: "Connect with brands that align with your content and audience for sponsored opportunities.",
        learnMore: "Learn more"
      },
      {
        title: "Content Optimization",
        description: "Expert advice on improving your content quality, engagement, and platform-specific strategies.",
        learnMore: "Learn more"
      },
      {
        title: "Monetization",
        description: "Diversify your revenue streams with subscriptions, merchandise, donations and exclusive content.",
        learnMore: "Learn more"
      },
      {
        title: "Community Building",
        description: "Strategies to develop and maintain an engaged, loyal community around your content.",
        learnMore: "Learn more"
      },
      {
        title: "Legal Support",
        description: "Contract negotiation, intellectual property protection, and compliance guidance.",
        learnMore: "Learn more"
      }
    ]
  },
  creators: {
    title: "OUR CREATORS",
    description: "Meet the talented streamers and content creators who are part of the VIRTUS family.",
    viewAll: "VIEW ALL CREATORS",
    liveTag: "LIVE",
    followers: "followers",
    views: "views"
  },
  apply: {
    title: "Ready to Take Your Content to the Next Level?",
    description: "Join our exclusive network of creators and streamers. Get the support, resources, and connections you need to grow your brand.",
    formTitle: "Apply to Join VIRTUS Agency",
    fullName: "Full Name",
    email: "Email Address",
    platform: "Primary Platform",
    selectPlatform: "Select your main platform",
    channelUrl: "Channel/Profile URL",
    aboutContent: "Tell Us About Your Content",
    submitButton: "SUBMIT APPLICATION",
    options: {
      twitch: "Twitch",
      youtube: "YouTube",
      tiktok: "TikTok",
      instagram: "Instagram",
      other: "Other"
    }
  },
  testimonials: {
    title: "SUCCESS STORIES",
    description: "Hear from creators who have grown their audience and income with VIRTUS Agency."
  },
  contact: {
    title: "GET IN TOUCH",
    description: "Have questions about our agency or services? We're here to help you navigate the world of content creation.",
    location: {
      title: "Our Location",
      address: "1234 Content Creator Avenue, Digital City"
    },
    email: {
      title: "Email Us",
      address: "info@virtusagency.com"
    },
    phone: {
      title: "Call Us",
      number: "+1 (555) 123-4567"
    },
    form: {
      title: "Send Us a Message",
      name: "Your Name",
      email: "Email Address",
      subject: "Subject",
      message: "Your Message",
      submitButton: "SEND MESSAGE"
    }
  },
  footer: {
    description: "Empowering creators to reach their full potential through strategic partnerships, growth opportunities, and community support.",
    quickLinks: "Quick Links",
    services: "Services",
    newsletter: {
      title: "Newsletter",
      description: "Subscribe to our newsletter for the latest updates, industry trends, and creator opportunities.",
      placeholder: "Your email address",
      button: "SUBSCRIBE"
    },
    copyright: "© 2023 VIRTUS Agency. All rights reserved.",
    termsLabel: "Terms & Conditions",
    privacyLabel: "Privacy Policy",
    cookiesLabel: "Cookies"
  },
  backToTop: "Back to top",
  search: {
    placeholder: "Search creators..."
  },
  language: "EN"
};

// Italian translations
const itTranslations = {
  navigation: {
    home: "HOME",
    services: "SERVIZI",
    creators: "CREATORI",
    about: "CHI SIAMO",
    contact: "CONTATTI"
  },
  hero: {
    heading1: "MIGLIORA LA TUA",
    heading2: "CARRIERA DI",
    heading3: "STREAMING",
    description: "Unisciti alla rete d'élite di creatori di contenuti e streamer. Ti aiutiamo a crescere, connetterti e monetizzare la tua passione.",
    joinButton: "UNISCITI A NOI",
    servicesButton: "I NOSTRI SERVIZI",
    discoverMore: "Scopri di più"
  },
  services: {
    title: "I NOSTRI SERVIZI",
    description: "Soluzioni complete per creatori di contenuti e streamer in ogni fase della loro carriera.",
    items: [
      {
        title: "Strategia di Crescita",
        description: "Piani personalizzati per aumentare i tuoi follower, spettatori e coinvolgimento su tutte le piattaforme.",
        learnMore: "Scopri di più"
      },
      {
        title: "Partnership con Brand",
        description: "Connettiti con marchi allineati con i tuoi contenuti e il tuo pubblico per opportunità sponsorizzate.",
        learnMore: "Scopri di più"
      },
      {
        title: "Ottimizzazione dei Contenuti",
        description: "Consigli di esperti per migliorare la qualità dei contenuti, il coinvolgimento e le strategie specifiche della piattaforma.",
        learnMore: "Scopri di più"
      },
      {
        title: "Monetizzazione",
        description: "Diversifica le fonti di reddito con abbonamenti, merchandising, donazioni e contenuti esclusivi.",
        learnMore: "Scopri di più"
      },
      {
        title: "Costruzione di Comunità",
        description: "Strategie per sviluppare e mantenere una comunità impegnata e fedele attorno ai tuoi contenuti.",
        learnMore: "Scopri di più"
      },
      {
        title: "Supporto Legale",
        description: "Negoziazione contrattuale, protezione della proprietà intellettuale e orientamento sulla conformità.",
        learnMore: "Scopri di più"
      }
    ]
  },
  creators: {
    title: "I NOSTRI CREATORI",
    description: "Incontra i talentuosi streamer e creatori di contenuti che fanno parte della famiglia VIRTUS.",
    viewAll: "VEDI TUTTI I CREATORI",
    liveTag: "LIVE",
    followers: "follower",
    views: "visualizzazioni"
  },
  apply: {
    title: "Pronto a Portare i Tuoi Contenuti al Livello Successivo?",
    description: "Unisciti alla nostra rete esclusiva di creatori e streamer. Ottieni il supporto, le risorse e le connessioni di cui hai bisogno per far crescere il tuo brand.",
    formTitle: "Candidati per Unirti a VIRTUS Agency",
    fullName: "Nome Completo",
    email: "Indirizzo Email",
    platform: "Piattaforma Principale",
    selectPlatform: "Seleziona la tua piattaforma principale",
    channelUrl: "URL del Canale/Profilo",
    aboutContent: "Parlaci dei tuoi Contenuti",
    submitButton: "INVIA CANDIDATURA",
    options: {
      twitch: "Twitch",
      youtube: "YouTube",
      tiktok: "TikTok",
      instagram: "Instagram",
      other: "Altro"
    }
  },
  testimonials: {
    title: "STORIE DI SUCCESSO",
    description: "Ascolta i creatori che hanno aumentato il loro pubblico e le loro entrate con VIRTUS Agency."
  },
  contact: {
    title: "CONTATTACI",
    description: "Hai domande sulla nostra agenzia o sui nostri servizi? Siamo qui per aiutarti a navigare nel mondo della creazione di contenuti.",
    location: {
      title: "La Nostra Sede",
      address: "1234 Content Creator Avenue, Città Digitale"
    },
    email: {
      title: "Email",
      address: "info@virtusagency.com"
    },
    phone: {
      title: "Chiamaci",
      number: "+1 (555) 123-4567"
    },
    form: {
      title: "Inviaci un Messaggio",
      name: "Il Tuo Nome",
      email: "Indirizzo Email",
      subject: "Oggetto",
      message: "Il Tuo Messaggio",
      submitButton: "INVIA MESSAGGIO"
    }
  },
  footer: {
    description: "Potenziare i creatori per raggiungere il loro pieno potenziale attraverso partnership strategiche, opportunità di crescita e supporto della comunità.",
    quickLinks: "Collegamenti Rapidi",
    services: "Servizi",
    newsletter: {
      title: "Newsletter",
      description: "Iscriviti alla nostra newsletter per gli ultimi aggiornamenti, tendenze del settore e opportunità per i creatori.",
      placeholder: "Il tuo indirizzo email",
      button: "ISCRIVITI"
    },
    copyright: "© 2023 VIRTUS Agency. Tutti i diritti riservati.",
    termsLabel: "Termini e Condizioni",
    privacyLabel: "Informativa sulla Privacy",
    cookiesLabel: "Cookie"
  },
  backToTop: "Torna all'inizio",
  search: {
    placeholder: "Cerca creatori..."
  },
  language: "IT"
};

// Spanish translations
const esTranslations = {
  navigation: {
    home: "INICIO",
    services: "SERVICIOS",
    creators: "CREADORES",
    about: "NOSOTROS",
    contact: "CONTACTO"
  },
  hero: {
    heading1: "ELEVA TU",
    heading2: "CARRERA DE",
    heading3: "STREAMING",
    description: "Únete a la red élite de creadores de contenido y streamers. Te ayudamos a crecer, conectar y monetizar tu pasión.",
    joinButton: "ÚNETE A NUESTRO EQUIPO",
    servicesButton: "NUESTROS SERVICIOS",
    discoverMore: "Descubre Más"
  },
  services: {
    title: "NUESTROS SERVICIOS",
    description: "Soluciones integrales para creadores de contenido y streamers en cada etapa de su carrera.",
    items: [
      {
        title: "Estrategia de Crecimiento",
        description: "Planes personalizados para aumentar tus seguidores, espectadores y engagement en todas las plataformas.",
        learnMore: "Saber más"
      },
      {
        title: "Asociaciones con Marcas",
        description: "Conéctate con marcas que se alineen con tu contenido y audiencia para oportunidades patrocinadas.",
        learnMore: "Saber más"
      },
      {
        title: "Optimización de Contenido",
        description: "Asesoramiento experto para mejorar la calidad de tu contenido, engagement y estrategias específicas para cada plataforma.",
        learnMore: "Saber más"
      },
      {
        title: "Monetización",
        description: "Diversifica tus fuentes de ingresos con suscripciones, merchandising, donaciones y contenido exclusivo.",
        learnMore: "Saber más"
      },
      {
        title: "Construcción de Comunidad",
        description: "Estrategias para desarrollar y mantener una comunidad comprometida y leal en torno a tu contenido.",
        learnMore: "Saber más"
      },
      {
        title: "Soporte Legal",
        description: "Negociación de contratos, protección de propiedad intelectual y orientación sobre cumplimiento normativo.",
        learnMore: "Saber más"
      }
    ]
  },
  creators: {
    title: "NUESTROS CREADORES",
    description: "Conoce a los talentosos streamers y creadores de contenido que forman parte de la familia VIRTUS.",
    viewAll: "VER TODOS LOS CREADORES",
    liveTag: "EN VIVO",
    followers: "seguidores",
    views: "vistas"
  },
  apply: {
    title: "¿Listo para Llevar tu Contenido al Siguiente Nivel?",
    description: "Únete a nuestra exclusiva red de creadores y streamers. Obtén el apoyo, los recursos y las conexiones que necesitas para hacer crecer tu marca.",
    formTitle: "Solicita Unirte a VIRTUS Agency",
    fullName: "Nombre Completo",
    email: "Correo Electrónico",
    platform: "Plataforma Principal",
    selectPlatform: "Selecciona tu plataforma principal",
    channelUrl: "URL del Canal/Perfil",
    aboutContent: "Cuéntanos Sobre tu Contenido",
    submitButton: "ENVIAR SOLICITUD",
    options: {
      twitch: "Twitch",
      youtube: "YouTube",
      tiktok: "TikTok",
      instagram: "Instagram",
      other: "Otro"
    }
  },
  testimonials: {
    title: "HISTORIAS DE ÉXITO",
    description: "Escucha a los creadores que han aumentado su audiencia e ingresos con VIRTUS Agency."
  },
  contact: {
    title: "CONTÁCTANOS",
    description: "¿Tienes preguntas sobre nuestra agencia o servicios? Estamos aquí para ayudarte a navegar en el mundo de la creación de contenido.",
    location: {
      title: "Nuestra Ubicación",
      address: "1234 Content Creator Avenue, Ciudad Digital"
    },
    email: {
      title: "Correo Electrónico",
      address: "info@virtusagency.com"
    },
    phone: {
      title: "Llámanos",
      number: "+1 (555) 123-4567"
    },
    form: {
      title: "Envíanos un Mensaje",
      name: "Tu Nombre",
      email: "Correo Electrónico",
      subject: "Asunto",
      message: "Tu Mensaje",
      submitButton: "ENVIAR MENSAJE"
    }
  },
  footer: {
    description: "Empoderando a los creadores para alcanzar su máximo potencial a través de asociaciones estratégicas, oportunidades de crecimiento y apoyo comunitario.",
    quickLinks: "Enlaces Rápidos",
    services: "Servicios",
    newsletter: {
      title: "Boletín",
      description: "Suscríbete a nuestro boletín para las últimas actualizaciones, tendencias de la industria y oportunidades para creadores.",
      placeholder: "Tu correo electrónico",
      button: "SUSCRIBIRSE"
    },
    copyright: "© 2023 VIRTUS Agency. Todos los derechos reservados.",
    termsLabel: "Términos y Condiciones",
    privacyLabel: "Política de Privacidad",
    cookiesLabel: "Cookies"
  },
  backToTop: "Volver arriba",
  search: {
    placeholder: "Buscar creadores..."
  },
  language: "ES"
};

// French translations
const frTranslations = {
  navigation: {
    home: "ACCUEIL",
    services: "SERVICES",
    creators: "CRÉATEURS",
    about: "À PROPOS",
    contact: "CONTACT"
  },
  hero: {
    heading1: "ÉLEVEZ VOTRE",
    heading2: "CARRIÈRE DE",
    heading3: "STREAMING",
    description: "Rejoignez le réseau d'élite des créateurs de contenu et des streamers. Nous vous aidons à vous développer, à vous connecter et à monétiser votre passion.",
    joinButton: "REJOIGNEZ NOTRE ÉQUIPE",
    servicesButton: "NOS SERVICES",
    discoverMore: "Découvrir Plus"
  },
  services: {
    title: "NOS SERVICES",
    description: "Des solutions complètes pour les créateurs de contenu et les streamers à chaque étape de leur carrière.",
    items: [
      {
        title: "Stratégie de Croissance",
        description: "Des plans personnalisés pour augmenter vos abonnés, spectateurs et engagement sur toutes les plateformes.",
        learnMore: "En savoir plus"
      },
      {
        title: "Partenariats avec des Marques",
        description: "Connectez-vous avec des marques qui s'alignent avec votre contenu et votre audience pour des opportunités sponsorisées.",
        learnMore: "En savoir plus"
      },
      {
        title: "Optimisation de Contenu",
        description: "Conseils d'experts pour améliorer la qualité de votre contenu, l'engagement et les stratégies spécifiques à chaque plateforme.",
        learnMore: "En savoir plus"
      },
      {
        title: "Monétisation",
        description: "Diversifiez vos sources de revenus avec des abonnements, du merchandising, des dons et du contenu exclusif.",
        learnMore: "En savoir plus"
      },
      {
        title: "Construction de Communauté",
        description: "Stratégies pour développer et maintenir une communauté engagée et fidèle autour de votre contenu.",
        learnMore: "En savoir plus"
      },
      {
        title: "Support Juridique",
        description: "Négociation de contrats, protection de la propriété intellectuelle et conseils de conformité.",
        learnMore: "En savoir plus"
      }
    ]
  },
  creators: {
    title: "NOS CRÉATEURS",
    description: "Rencontrez les streamers talentueux et les créateurs de contenu qui font partie de la famille VIRTUS.",
    viewAll: "VOIR TOUS LES CRÉATEURS",
    liveTag: "EN DIRECT",
    followers: "abonnés",
    views: "vues"
  },
  apply: {
    title: "Prêt à Porter Votre Contenu au Niveau Supérieur?",
    description: "Rejoignez notre réseau exclusif de créateurs et de streamers. Obtenez le soutien, les ressources et les connexions dont vous avez besoin pour développer votre marque.",
    formTitle: "Postulez pour Rejoindre VIRTUS Agency",
    fullName: "Nom Complet",
    email: "Adresse Email",
    platform: "Plateforme Principale",
    selectPlatform: "Sélectionnez votre plateforme principale",
    channelUrl: "URL de Chaîne/Profil",
    aboutContent: "Parlez-nous de Votre Contenu",
    submitButton: "SOUMETTRE LA CANDIDATURE",
    options: {
      twitch: "Twitch",
      youtube: "YouTube",
      tiktok: "TikTok",
      instagram: "Instagram",
      other: "Autre"
    }
  },
  testimonials: {
    title: "HISTOIRES DE RÉUSSITE",
    description: "Écoutez les créateurs qui ont augmenté leur audience et leurs revenus avec VIRTUS Agency."
  },
  contact: {
    title: "CONTACTEZ-NOUS",
    description: "Vous avez des questions sur notre agence ou nos services? Nous sommes là pour vous aider à naviguer dans le monde de la création de contenu.",
    location: {
      title: "Notre Emplacement",
      address: "1234 Content Creator Avenue, Ville Numérique"
    },
    email: {
      title: "Email",
      address: "info@virtusagency.com"
    },
    phone: {
      title: "Appelez-nous",
      number: "+1 (555) 123-4567"
    },
    form: {
      title: "Envoyez-nous un Message",
      name: "Votre Nom",
      email: "Adresse Email",
      subject: "Sujet",
      message: "Votre Message",
      submitButton: "ENVOYER LE MESSAGE"
    }
  },
  footer: {
    description: "Donner aux créateurs les moyens d'atteindre leur plein potentiel grâce à des partenariats stratégiques, des opportunités de croissance et un soutien communautaire.",
    quickLinks: "Liens Rapides",
    services: "Services",
    newsletter: {
      title: "Newsletter",
      description: "Abonnez-vous à notre newsletter pour les dernières mises à jour, les tendances de l'industrie et les opportunités pour les créateurs.",
      placeholder: "Votre adresse email",
      button: "S'ABONNER"
    },
    copyright: "© 2023 VIRTUS Agency. Tous droits réservés.",
    termsLabel: "Termes et Conditions",
    privacyLabel: "Politique de Confidentialité",
    cookiesLabel: "Cookies"
  },
  backToTop: "Retour en haut",
  search: {
    placeholder: "Rechercher des créateurs..."
  },
  language: "FR"
};

// Romanian translations
const roTranslations = {
  navigation: {
    home: "ACASĂ",
    services: "SERVICII",
    creators: "CREATORI",
    about: "DESPRE NOI",
    contact: "CONTACT"
  },
  hero: {
    heading1: "RIDICĂ-ȚI",
    heading2: "CARIERA DE",
    heading3: "STREAMING",
    description: "Alătură-te rețelei de elită a creatorilor de conținut și streamerilor. Te ajutăm să crești, să te conectezi și să îți monetizezi pasiunea.",
    joinButton: "ALĂTURĂ-TE ECHIPEI NOASTRE",
    servicesButton: "SERVICIILE NOASTRE",
    discoverMore: "Descoperă Mai Mult"
  },
  services: {
    title: "SERVICIILE NOASTRE",
    description: "Soluții complete pentru creatori de conținut și streameri în fiecare etapă a carierei lor.",
    items: [
      {
        title: "Strategie de Creștere",
        description: "Planuri personalizate pentru a-ți crește numărul de urmăritori, spectatori și implicarea pe toate platformele.",
        learnMore: "Află mai mult"
      },
      {
        title: "Parteneriate cu Branduri",
        description: "Conectează-te cu branduri care se aliniază cu conținutul tău și audiența ta pentru oportunități sponsorizate.",
        learnMore: "Află mai mult"
      },
      {
        title: "Optimizarea Conținutului",
        description: "Sfaturi de experți pentru îmbunătățirea calității conținutului, a implicării și a strategiilor specifice platformei.",
        learnMore: "Află mai mult"
      },
      {
        title: "Monetizare",
        description: "Diversifică-ți sursele de venit cu abonamente, produse promoționale, donații și conținut exclusiv.",
        learnMore: "Află mai mult"
      },
      {
        title: "Construirea Comunității",
        description: "Strategii pentru a dezvolta și menține o comunitate implicată și loială în jurul conținutului tău.",
        learnMore: "Află mai mult"
      },
      {
        title: "Suport Juridic",
        description: "Negocierea contractelor, protecția proprietății intelectuale și orientare în privința conformității.",
        learnMore: "Află mai mult"
      }
    ]
  },
  creators: {
    title: "CREATORII NOȘTRI",
    description: "Întâlnește streamerii talentați și creatorii de conținut care fac parte din familia VIRTUS.",
    viewAll: "VEZI TOȚI CREATORII",
    liveTag: "ÎN DIRECT",
    followers: "urmăritori",
    views: "vizualizări"
  },
  apply: {
    title: "Pregătit să-ți Duci Conținutul la Nivelul Următor?",
    description: "Alătură-te rețelei noastre exclusive de creatori și streameri. Obține suportul, resursele și conexiunile de care ai nevoie pentru a-ți dezvolta brandul.",
    formTitle: "Aplică pentru a Te Alătura VIRTUS Agency",
    fullName: "Nume Complet",
    email: "Adresă de Email",
    platform: "Platformă Principală",
    selectPlatform: "Selectează platforma ta principală",
    channelUrl: "URL Canal/Profil",
    aboutContent: "Spune-ne Despre Conținutul Tău",
    submitButton: "TRIMITE APLICAȚIA",
    options: {
      twitch: "Twitch",
      youtube: "YouTube",
      tiktok: "TikTok",
      instagram: "Instagram",
      other: "Altele"
    }
  },
  testimonials: {
    title: "POVEȘTI DE SUCCES",
    description: "Ascultă creatorii care și-au crescut audiența și veniturile cu VIRTUS Agency."
  },
  contact: {
    title: "CONTACTEAZĂ-NE",
    description: "Ai întrebări despre agenția noastră sau serviciile noastre? Suntem aici pentru a te ajuta să navighezi în lumea creării de conținut.",
    location: {
      title: "Locația Noastră",
      address: "1234 Content Creator Avenue, Orașul Digital"
    },
    email: {
      title: "Email",
      address: "info@virtusagency.com"
    },
    phone: {
      title: "Sună-ne",
      number: "+1 (555) 123-4567"
    },
    form: {
      title: "Trimite-ne un Mesaj",
      name: "Numele Tău",
      email: "Adresă de Email",
      subject: "Subiect",
      message: "Mesajul Tău",
      submitButton: "TRIMITE MESAJ"
    }
  },
  footer: {
    description: "Împuternicim creatorii să-și atingă potențialul maxim prin parteneriate strategice, oportunități de creștere și sprijin comunitar.",
    quickLinks: "Linkuri Rapide",
    services: "Servicii",
    newsletter: {
      title: "Newsletter",
      description: "Abonează-te la newsletter-ul nostru pentru cele mai recente actualizări, tendințe din industrie și oportunități pentru creatori.",
      placeholder: "Adresa ta de email",
      button: "ABONEAZĂ-TE"
    },
    copyright: "© 2023 VIRTUS Agency. Toate drepturile rezervate.",
    termsLabel: "Termeni și Condiții",
    privacyLabel: "Politica de Confidențialitate",
    cookiesLabel: "Cookies"
  },
  backToTop: "Înapoi sus",
  search: {
    placeholder: "Caută creatori..."
  },
  language: "RO"
};

// Initialize i18n
i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: enTranslations },
      it: { translation: itTranslations },
      es: { translation: esTranslations },
      fr: { translation: frTranslations },
      ro: { translation: roTranslations }
    },
    lng: "en", // Default language
    fallbackLng: "en",
    interpolation: {
      escapeValue: false // React already escapes values
    }
  });

export default i18n;
