import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import LanguageSwitcher from "./LanguageSwitcher";
import { Search } from "lucide-react";

const Header = () => {
  const { t } = useTranslation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll event to add shadow to header when scrolled
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={`fixed w-full z-50 bg-virtus-black ${isScrolled ? 'bg-opacity-95 border-b border-[#FFD700] border-opacity-20' : 'bg-opacity-90'} transition-all duration-300`}>
      <div className="container mx-auto px-4 md:px-6 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#FFD700] to-[#B8860B] flex items-center justify-center shadow-lg">
              <span className="font-montserrat font-bold text-virtus-black text-xl">V</span>
            </div>
            <span className="font-montserrat font-bold text-xl text-white">VIRTUS <span className="text-[#FFD700]">Agency</span></span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="font-montserrat text-sm text-white hover:text-[#FFD700] transition duration-300">
              {t('navigation.home')}
            </a>
            <a href="#services" className="font-montserrat text-sm text-white hover:text-[#FFD700] transition duration-300">
              {t('navigation.services')}
            </a>
            <a href="#creators" className="font-montserrat text-sm text-white hover:text-[#FFD700] transition duration-300">
              {t('navigation.creators')}
            </a>
            <a href="#about" className="font-montserrat text-sm text-white hover:text-[#FFD700] transition duration-300">
              {t('navigation.about')}
            </a>
            <a href="#contact" className="font-montserrat text-sm text-white hover:text-[#FFD700] transition duration-300">
              {t('navigation.contact')}
            </a>
          </nav>
          
          {/* Right Side Elements */}
          <div className="flex items-center space-x-4">
            {/* Search Bar */}
            <div className="hidden sm:block relative">
              <input 
                type="text" 
                placeholder={t('search.placeholder')}
                className="w-[180px] focus:w-[250px] py-1 px-3 bg-[#171717] text-sm text-white border border-[#FFD700] border-opacity-30 rounded-full focus:outline-none focus:border-[#20B2AA] transition-all duration-300"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#FFD700] h-4 w-4" />
            </div>
            
            {/* Language Selector */}
            <LanguageSwitcher />
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white focus:outline-none"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={`md:hidden bg-[#171717] border-t border-[#FFD700] border-opacity-20 transition-all duration-300 ${isMenuOpen ? 'block' : 'hidden'}`}>
        <div className="py-4 px-6 space-y-4">
          <a 
            href="#home" 
            className="block font-montserrat text-white hover:text-[#FFD700] transition duration-300"
            onClick={() => setIsMenuOpen(false)}
          >
            {t('navigation.home')}
          </a>
          <a 
            href="#services" 
            className="block font-montserrat text-white hover:text-[#FFD700] transition duration-300"
            onClick={() => setIsMenuOpen(false)}
          >
            {t('navigation.services')}
          </a>
          <a 
            href="#creators" 
            className="block font-montserrat text-white hover:text-[#FFD700] transition duration-300"
            onClick={() => setIsMenuOpen(false)}
          >
            {t('navigation.creators')}
          </a>
          <a 
            href="#about" 
            className="block font-montserrat text-white hover:text-[#FFD700] transition duration-300"
            onClick={() => setIsMenuOpen(false)}
          >
            {t('navigation.about')}
          </a>
          <a 
            href="#contact" 
            className="block font-montserrat text-white hover:text-[#FFD700] transition duration-300"
            onClick={() => setIsMenuOpen(false)}
          >
            {t('navigation.contact')}
          </a>
          <div className="pt-2">
            <input 
              type="text" 
              placeholder={t('search.placeholder')}
              className="w-full py-2 px-3 bg-virtus-black text-sm text-white border border-[#FFD700] border-opacity-30 rounded-full focus:outline-none focus:border-[#20B2AA]"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
