import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { MapPin, Mail, Phone, Twitter, Instagram, Linkedin, MessageSquare } from "lucide-react";
import { FaDiscord } from "react-icons/fa";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  subject: z.string().min(2, {
    message: "Subject must be at least 2 characters.",
  }),
  message: z.string().min(10, {
    message: "Message must be at least 10 characters.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const Contact = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: (values: FormValues) => 
      apiRequest("POST", "/api/contact", values).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Message sent",
        description: "Thank you for contacting us! We'll get back to you soon.",
        duration: 5000,
      });
      form.reset();
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message. Please try again.",
        duration: 5000,
      });
      setIsSubmitting(false);
    }
  });

  function onSubmit(values: FormValues) {
    setIsSubmitting(true);
    contactMutation.mutate(values);
  }

  return (
    <section id="contact" className="py-20 bg-[#171717]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <span className="inline-block h-1 w-20 bg-[#20B2AA] mb-4"></span>
            <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-white mb-6">
              {t('contact.title')}
            </h2>
            <p className="text-lg text-[#E5E5E5] mb-8">
              {t('contact.description')}
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <div className="h-10 w-10 rounded-full bg-[#FFD700] bg-opacity-10 flex items-center justify-center mr-4">
                  <MapPin className="text-[#FFD700]" />
                </div>
                <div>
                  <h4 className="font-montserrat font-bold text-white mb-1">
                    {t('contact.location.title')}
                  </h4>
                  <p className="text-[#E5E5E5]">
                    {t('contact.location.address')}
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-10 w-10 rounded-full bg-[#20B2AA] bg-opacity-10 flex items-center justify-center mr-4">
                  <Mail className="text-[#20B2AA]" />
                </div>
                <div>
                  <h4 className="font-montserrat font-bold text-white mb-1">
                    {t('contact.email.title')}
                  </h4>
                  <p className="text-[#E5E5E5]">
                    {t('contact.email.address')}
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-10 w-10 rounded-full bg-[#FFD700] bg-opacity-10 flex items-center justify-center mr-4">
                  <Phone className="text-[#FFD700]" />
                </div>
                <div>
                  <h4 className="font-montserrat font-bold text-white mb-1">
                    {t('contact.phone.title')}
                  </h4>
                  <p className="text-[#E5E5E5]">
                    {t('contact.phone.number')}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-4">
              <a href="#" className="h-12 w-12 rounded-full bg-virtus-black border border-[#FFD700] border-opacity-30 flex items-center justify-center text-[#FFD700] hover:bg-[#FFD700] hover:text-virtus-black transition duration-300">
                <Twitter size={20} />
              </a>
              <a href="#" className="h-12 w-12 rounded-full bg-virtus-black border border-[#FFD700] border-opacity-30 flex items-center justify-center text-[#FFD700] hover:bg-[#FFD700] hover:text-virtus-black transition duration-300">
                <Instagram size={20} />
              </a>
              <a href="#" className="h-12 w-12 rounded-full bg-virtus-black border border-[#FFD700] border-opacity-30 flex items-center justify-center text-[#FFD700] hover:bg-[#FFD700] hover:text-virtus-black transition duration-300">
                <Linkedin size={20} />
              </a>
              <a href="#" className="h-12 w-12 rounded-full bg-virtus-black border border-[#FFD700] border-opacity-30 flex items-center justify-center text-[#FFD700] hover:bg-[#FFD700] hover:text-virtus-black transition duration-300">
                <FaDiscord size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <div className="bg-virtus-black p-8 rounded-xl border border-[#20B2AA] border-opacity-20">
              <h3 className="font-montserrat font-bold text-2xl text-white mb-6">
                {t('contact.form.title')}
              </h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('contact.form.name')}</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              className="bg-[#171717] border border-[#20B2AA] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('contact.form.email')}</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              type="email" 
                              className="bg-[#171717] border border-[#20B2AA] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('contact.form.subject')}</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            className="bg-[#171717] border border-[#20B2AA] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('contact.form.message')}</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            rows={4} 
                            className="bg-[#171717] border border-[#20B2AA] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-2">
                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="w-full font-poppins font-medium py-3 px-8 bg-gradient-to-r from-[#20B2AA] to-[#008080] text-white rounded-lg shadow-lg hover:from-[#008080] hover:to-[#20B2AA] transition duration-300"
                    >
                      {isSubmitting ? "Sending..." : t('contact.form.submitButton')}
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
