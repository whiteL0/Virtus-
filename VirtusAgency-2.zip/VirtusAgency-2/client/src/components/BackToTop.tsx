import { useTranslation } from "react-i18next";
import { ChevronUp } from "lucide-react";

interface BackToTopProps {
  onClick: () => void;
}

const BackToTop = ({ onClick }: BackToTopProps) => {
  const { t } = useTranslation();
  
  return (
    <button
      onClick={onClick}
      aria-label={t('backToTop')}
      className="fixed bottom-6 right-6 h-12 w-12 rounded-full bg-[#FFD700] flex items-center justify-center text-virtus-black shadow-lg hover:bg-[#B8860B] transition duration-300 z-50"
    >
      <ChevronUp className="h-6 w-6" />
    </button>
  );
};

export default BackToTop;
