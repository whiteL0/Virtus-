import { useTranslation } from "react-i18next";
import { TrendingUp, Handshake, Video, DollarSign, Users, Shield, ArrowRight } from "lucide-react";

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  learnMore: string;
  color: "teal" | "gold";
}

const ServiceCard = ({ icon, title, description, learnMore, color }: ServiceCardProps) => {
  const gradientClass = color === "teal" 
    ? "bg-gradient-to-br from-[#20B2AA] to-[#008080]" 
    : "bg-gradient-to-br from-[#FFD700] to-[#B8860B]";
  
  const textColor = color === "teal" ? "text-[#20B2AA]" : "text-[#FFD700]";
  const hoverColor = color === "teal" ? "hover:text-[#FFD700]" : "hover:text-[#20B2AA]";

  return (
    <div className="bg-[#171717] border border-[#FFD700] border-opacity-10 rounded-xl p-8 hover:-translate-y-1 hover:shadow-lg hover:shadow-[#20B2AA]/30 transition duration-300">
      <div className={`h-14 w-14 rounded-full ${gradientClass} flex items-center justify-center mb-6`}>
        {icon}
      </div>
      <h3 className="font-montserrat font-bold text-xl text-white mb-4">{title}</h3>
      <p className="text-[#E5E5E5] mb-6">{description}</p>
      <a href="#" className={`flex items-center font-poppins ${textColor} ${hoverColor} transition duration-300`}>
        <span>{learnMore}</span>
        <ArrowRight className="ml-2 h-4 w-4" />
      </a>
    </div>
  );
};

const Services = () => {
  const { t } = useTranslation();
  
  const services = [
    {
      icon: <TrendingUp className="text-2xl text-white" />,
      title: t('services.items.0.title'),
      description: t('services.items.0.description'),
      learnMore: t('services.items.0.learnMore'),
      color: "teal" as const
    },
    {
      icon: <Handshake className="text-2xl text-virtus-black" />,
      title: t('services.items.1.title'),
      description: t('services.items.1.description'),
      learnMore: t('services.items.1.learnMore'),
      color: "gold" as const
    },
    {
      icon: <Video className="text-2xl text-white" />,
      title: t('services.items.2.title'),
      description: t('services.items.2.description'),
      learnMore: t('services.items.2.learnMore'),
      color: "teal" as const
    },
    {
      icon: <DollarSign className="text-2xl text-virtus-black" />,
      title: t('services.items.3.title'),
      description: t('services.items.3.description'),
      learnMore: t('services.items.3.learnMore'),
      color: "gold" as const
    },
    {
      icon: <Users className="text-2xl text-white" />,
      title: t('services.items.4.title'),
      description: t('services.items.4.description'),
      learnMore: t('services.items.4.learnMore'),
      color: "teal" as const
    },
    {
      icon: <Shield className="text-2xl text-virtus-black" />,
      title: t('services.items.5.title'),
      description: t('services.items.5.description'),
      learnMore: t('services.items.5.learnMore'),
      color: "gold" as const
    }
  ];

  return (
    <section id="services" className="py-20 bg-virtus-black">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <span className="inline-block h-1 w-20 bg-[#20B2AA] mb-4"></span>
          <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-white mb-4">
            {t('services.title')}
          </h2>
          <p className="text-[#E5E5E5] max-w-2xl mx-auto">
            {t('services.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard 
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              learnMore={service.learnMore}
              color={service.color}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
