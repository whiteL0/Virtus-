import { useTranslation } from "react-i18next";
import { ChevronDown } from "lucide-react";

const Hero = () => {
  const { t } = useTranslation();

  return (
    <section id="home" className="min-h-screen relative flex items-center pt-24 bg-virtus-black">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0 bg-gradient-to-r from-[rgba(13,13,13,0.9)] to-[rgba(13,13,13,0.7)]" style={{
        backgroundImage: "url('https://images.unsplash.com/photo-1598550473359-433795503a0f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundBlendMode: "overlay"
      }} />
      
      <div className="container mx-auto px-4 md:px-6 py-20 relative z-10">
        <div className="max-w-3xl">
          <h1 className="font-montserrat font-bold text-4xl md:text-6xl text-white leading-tight text-shadow mb-6">
            <span className="block">{t('hero.heading1')}</span>
            <span className="text-[#FFD700]">{t('hero.heading2')}</span>
            <span className="block">{t('hero.heading3')}</span>
          </h1>
          <p className="text-lg md:text-xl text-[#E5E5E5] mb-10 max-w-xl text-shadow">
            {t('hero.description')}
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
            <a 
              href="#apply" 
              className="inline-block font-poppins font-medium py-3 px-8 bg-[#FFD700] text-virtus-black rounded-full shadow-lg hover:bg-[#B8860B] transition duration-300 text-center"
            >
              {t('hero.joinButton')}
            </a>
            <a 
              href="#services" 
              className="inline-block font-poppins font-medium py-3 px-8 bg-transparent border-2 border-[#20B2AA] text-[#20B2AA] rounded-full hover:bg-[#20B2AA] hover:bg-opacity-10 transition duration-300 text-center"
            >
              {t('hero.servicesButton')}
            </a>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white text-center">
          <p className="text-sm text-[#E5E5E5] mb-2">{t('hero.discoverMore')}</p>
          <ChevronDown className="text-[#FFD700] animate-bounce h-6 w-6 mx-auto" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
