import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { User, Eye } from "lucide-react";
import { 
  FaTwitch, 
  FaYoutube, 
  FaInstagram, 
  FaTwitter, 
  FaTiktok, 
  FaDiscord, 
  FaSpotify, 
  FaSoundcloud 
} from "react-icons/fa";

interface PlatformIconProps {
  platform: string;
  className?: string;
}

const PlatformIcon = ({ platform, className = "" }: PlatformIconProps) => {
  const iconClass = `${className} transition`;
  
  switch (platform) {
    case "twitch":
      return <FaTwitch className={iconClass} />;
    case "youtube":
      return <FaYoutube className={iconClass} />;
    case "instagram":
      return <FaInstagram className={iconClass} />;
    case "twitter":
      return <FaTwitter className={iconClass} />;
    case "tiktok":
      return <FaTiktok className={iconClass} />;
    case "discord":
      return <FaDiscord className={iconClass} />;
    case "spotify":
      return <FaSpotify className={iconClass} />;
    case "soundcloud":
      return <FaSoundcloud className={iconClass} />;
    default:
      return null;
  }
};

interface Creator {
  id: number;
  name: string;
  specialty: string;
  followers: number;
  views: number;
  platforms: string; // JSON string array
  imageUrl: string;
  isLive: boolean;
}

interface CreatorCardProps {
  creator: Creator;
  liveTag: string;
  followers: string;
  views: string;
}

const CreatorCard = ({ creator, liveTag, followers, views }: CreatorCardProps) => {
  const platforms = JSON.parse(creator.platforms) as string[];
  
  return (
    <div className="relative bg-[#171717] rounded-xl overflow-hidden hover:-translate-y-1 hover:shadow-lg hover:shadow-[#20B2AA]/30 transition duration-300 group">
      <div className="h-60 overflow-hidden">
        <img 
          src={creator.imageUrl} 
          alt={`${creator.name} profile`} 
          className="w-full h-full object-cover transform group-hover:scale-105 transition duration-500"
        />
      </div>
      {creator.isLive && (
        <div className="absolute top-4 right-4">
          <span className="inline-block bg-red-600 text-white text-xs px-2 py-1 rounded-md">
            {liveTag}
          </span>
        </div>
      )}
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-montserrat font-bold text-xl text-white">{creator.name}</h3>
          <div className="flex space-x-2">
            {platforms.map((platform, index) => (
              <a 
                key={index} 
                href="#" 
                className="text-[#E5E5E5] hover:text-[#20B2AA] transition"
              >
                <PlatformIcon platform={platform} />
              </a>
            ))}
          </div>
        </div>
        <p className="text-sm text-[#E5E5E5] mb-3">{creator.specialty}</p>
        <div className="flex items-center text-xs text-[#E5E5E5]">
          <span className="mr-4 flex items-center">
            <User className="mr-1 h-3 w-3" /> 
            {creator.followers.toLocaleString()}
            {" "}
            {followers}
          </span>
          <span className="flex items-center">
            <Eye className="mr-1 h-3 w-3" /> 
            {creator.views.toLocaleString()} 
            {" "}
            {views}
          </span>
        </div>
      </div>
    </div>
  );
};

const CreatorsLoading = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {[1, 2, 3, 4].map((n) => (
        <div key={n} className="bg-[#171717] rounded-xl overflow-hidden animate-pulse">
          <div className="h-60 bg-gray-800"></div>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="h-6 bg-gray-700 rounded w-1/2"></div>
              <div className="flex space-x-2">
                <div className="h-4 w-4 bg-gray-700 rounded-full"></div>
                <div className="h-4 w-4 bg-gray-700 rounded-full"></div>
                <div className="h-4 w-4 bg-gray-700 rounded-full"></div>
              </div>
            </div>
            <div className="h-4 bg-gray-700 rounded w-3/4 mb-3"></div>
            <div className="flex items-center">
              <div className="h-3 bg-gray-700 rounded w-1/4 mr-4"></div>
              <div className="h-3 bg-gray-700 rounded w-1/4"></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const Creators = () => {
  const { t } = useTranslation();
  
  const { data: creators, isLoading, error } = useQuery({
    queryKey: ["/api/creators"],
    staleTime: 60000 // 1 minute
  });

  return (
    <section id="creators" className="py-20 bg-gradient-to-b from-virtus-black to-[#171717]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <span className="inline-block h-1 w-20 bg-[#FFD700] mb-4"></span>
          <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-white mb-4">
            {t('creators.title')}
          </h2>
          <p className="text-[#E5E5E5] max-w-2xl mx-auto">
            {t('creators.description')}
          </p>
        </div>
        
        {isLoading ? (
          <CreatorsLoading />
        ) : error ? (
          <div className="text-center text-red-500 py-8">
            Error loading creators. Please try again later.
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {creators.map((creator: Creator) => (
                <CreatorCard 
                  key={creator.id} 
                  creator={creator} 
                  liveTag={t('creators.liveTag')}
                  followers={t('creators.followers')}
                  views={t('creators.views')}
                />
              ))}
            </div>
            
            <div className="text-center mt-12">
              <a 
                href="#" 
                className="inline-block font-poppins font-medium py-3 px-8 border-2 border-[#FFD700] text-[#FFD700] rounded-full hover:bg-[#FFD700] hover:text-virtus-black transition duration-300"
              >
                {t('creators.viewAll')}
              </a>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default Creators;
