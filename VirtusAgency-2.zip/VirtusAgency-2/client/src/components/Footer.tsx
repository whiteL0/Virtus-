import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Twitter, Instagram, Linkedin, Youtube } from "lucide-react";

const emailSchema = z.object({
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
});

const Footer = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isSubscribing, setIsSubscribing] = useState(false);

  const newsletterMutation = useMutation({
    mutationFn: (data: { email: string }) => 
      apiRequest("POST", "/api/newsletter", data).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Subscribed!",
        description: "Thank you for subscribing to our newsletter.",
        duration: 5000,
      });
      setEmail("");
      setIsSubscribing(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to subscribe. Please try again.",
        duration: 5000,
      });
      setIsSubscribing(false);
    }
  });

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { email: validatedEmail } = emailSchema.parse({ email });
      setIsSubscribing(true);
      newsletterMutation.mutate({ email: validatedEmail });
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          variant: "destructive",
          title: "Invalid email",
          description: "Please enter a valid email address.",
          duration: 5000,
        });
      }
    }
  };

  return (
    <footer className="bg-virtus-black border-t border-[#FFD700] border-opacity-20">
      <div className="container mx-auto px-4 md:px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Logo and About */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#FFD700] to-[#B8860B] flex items-center justify-center shadow-lg">
                <span className="font-montserrat font-bold text-virtus-black text-xl">V</span>
              </div>
              <span className="font-montserrat font-bold text-xl text-white">VIRTUS <span className="text-[#FFD700]">Agency</span></span>
            </div>
            <p className="text-[#E5E5E5] mb-6">
              {t('footer.description')}
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] transition duration-300">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] transition duration-300">
                <Instagram size={18} />
              </a>
              <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] transition duration-300">
                <Linkedin size={18} />
              </a>
              <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] transition duration-300">
                <Youtube size={18} />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="font-montserrat font-bold text-lg text-white mb-6">
              {t('footer.quickLinks')}
            </h4>
            <ul className="space-y-3">
              <li>
                <a href="#home" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('navigation.home')}
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('navigation.services')}
                </a>
              </li>
              <li>
                <a href="#creators" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('navigation.creators')}
                </a>
              </li>
              <li>
                <a href="#about" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('navigation.about')}
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('navigation.contact')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('footer.privacyLabel')}
                </a>
              </li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h4 className="font-montserrat font-bold text-lg text-white mb-6">
              {t('footer.services')}
            </h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('services.items.0.title')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('services.items.1.title')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('services.items.2.title')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('services.items.3.title')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('services.items.4.title')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#E5E5E5] hover:text-[#20B2AA] transition duration-300">
                  {t('services.items.5.title')}
                </a>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h4 className="font-montserrat font-bold text-lg text-white mb-6">
              {t('footer.newsletter.title')}
            </h4>
            <p className="text-[#E5E5E5] mb-4">
              {t('footer.newsletter.description')}
            </p>
            <form className="space-y-3" onSubmit={handleSubscribe}>
              <div>
                <Input
                  type="email"
                  placeholder={t('footer.newsletter.placeholder')}
                  className="w-full bg-[#171717] border border-[#FFD700] border-opacity-30 rounded-lg py-3 px-4 text-white focus:outline-none focus:border-[#20B2AA]"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <Button 
                type="submit" 
                disabled={isSubscribing}
                className="w-full font-poppins py-3 px-6 bg-[#FFD700] text-virtus-black rounded-lg hover:bg-[#B8860B] transition duration-300"
              >
                {isSubscribing ? "Subscribing..." : t('footer.newsletter.button')}
              </Button>
            </form>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-[#FFD700] border-opacity-10 flex flex-col md:flex-row justify-between items-center">
          <p className="text-[#E5E5E5] text-sm mb-4 md:mb-0">
            {t('footer.copyright')}
          </p>
          <div className="flex items-center space-x-4">
            <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] text-sm transition duration-300">
              {t('footer.termsLabel')}
            </a>
            <span className="text-[#FFD700]">•</span>
            <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] text-sm transition duration-300">
              {t('footer.privacyLabel')}
            </a>
            <span className="text-[#FFD700]">•</span>
            <a href="#" className="text-[#E5E5E5] hover:text-[#FFD700] text-sm transition duration-300">
              {t('footer.cookiesLabel')}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
