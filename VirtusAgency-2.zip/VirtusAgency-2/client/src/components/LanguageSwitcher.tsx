import { useState, useRef, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Globe, Check, ChevronDown } from "lucide-react";

const languages = [
  { code: "en", name: "English", flag: "gb" },
  { code: "it", name: "Italiano", flag: "it" },
  { code: "es", name: "Español", flag: "es" },
  { code: "fr", name: "Français", flag: "fr" },
  { code: "ro", name: "Română", flag: "ro" }
];

const LanguageSwitcher = () => {
  const { i18n, t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const changeLanguage = (language: string) => {
    i18n.changeLanguage(language);
    setIsOpen(false);
  };

  const getCurrentLanguage = () => {
    return languages.find((lang) => lang.code === i18n.language) || languages[0];
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        className="flex items-center space-x-1 text-white hover:text-[#FFD700] focus:outline-none transition duration-300"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Globe className="text-[#20B2AA] h-4 w-4" />
        <span className="hidden sm:inline text-sm">{t('language')}</span>
        <ChevronDown className="h-3 w-3" />
      </button>
      
      {isOpen && (
        <div className="absolute right-0 mt-2 w-40 bg-[#171717] border border-[#FFD700] border-opacity-20 rounded-md shadow-lg z-10">
          <div className="p-2 space-y-1">
            {languages.map((language) => (
              <button
                key={language.code}
                className="flex items-center space-x-2 p-2 text-sm text-white hover:bg-[#FFD700] hover:bg-opacity-10 rounded w-full text-left"
                onClick={() => changeLanguage(language.code)}
              >
                <span className={`fi fi-${language.flag}`}></span>
                <span>{language.name}</span>
                {i18n.language === language.code && (
                  <Check className="text-[#FFD700] ml-auto h-3 w-3" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageSwitcher;
