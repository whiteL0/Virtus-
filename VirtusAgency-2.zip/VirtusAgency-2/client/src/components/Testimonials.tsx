import { useTranslation } from "react-i18next";

interface Testimonial {
  quote: string;
  name: string;
  role: string;
  image: string;
}

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  return (
    <div className="bg-[#171717] rounded-xl p-8 relative">
      <div className="text-[#FFD700] text-5xl absolute -top-4 -left-2 opacity-20">"</div>
      <p className="text-[#E5E5E5] mb-6 italic relative z-10">{testimonial.quote}</p>
      <div className="flex items-center">
        <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
          <img src={testimonial.image} alt={`${testimonial.name} profile`} className="w-full h-full object-cover" />
        </div>
        <div>
          <h4 className="font-montserrat font-bold text-white">{testimonial.name}</h4>
          <p className="text-sm text-[#E5E5E5]">{testimonial.role}</p>
        </div>
      </div>
    </div>
  );
};

const Testimonials = () => {
  const { t } = useTranslation();
  
  const testimonials: Testimonial[] = [
    {
      quote: "Since joining VIRTUS, my average viewers increased by 300% and I've secured partnerships with major gaming brands. The team truly understands the creator economy.",
      name: "Alex G.",
      role: "FPS Streamer, 500K followers",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80"
    },
    {
      quote: "The guidance on content strategy and monetization has been invaluable. VIRTUS helped me turn my passion into a full-time career with diverse revenue streams.",
      name: "Sophia R.",
      role: "Lifestyle Content Creator, 1.2M followers",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80"
    },
    {
      quote: "What sets VIRTUS apart is their personalized approach. They don't just see numbers, they understand my unique content style and help me amplify it to the right audience.",
      name: "Marcus T.",
      role: "Tech Reviewer, 750K subscribers",
      image: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80"
    }
  ];

  return (
    <section className="py-20 bg-virtus-black">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <span className="inline-block h-1 w-20 bg-[#FFD700] mb-4"></span>
          <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-white mb-4">
            {t('testimonials.title')}
          </h2>
          <p className="text-[#E5E5E5] max-w-2xl mx-auto">
            {t('testimonials.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
