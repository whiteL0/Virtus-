import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

const formSchema = z.object({
  fullName: z.string().min(2, {
    message: "Full name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  platform: z.string().min(1, {
    message: "Please select your primary platform.",
  }),
  channelUrl: z.string().url({
    message: "Please enter a valid URL.",
  }),
  message: z.string().min(10, {
    message: "Your message must be at least 10 characters.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const JoinCTA = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      platform: "",
      channelUrl: "",
      message: "",
    },
  });

  const applicationMutation = useMutation({
    mutationFn: (values: FormValues) => 
      apiRequest("POST", "/api/apply", values).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Application submitted",
        description: "We'll review your application and get back to you soon!",
        duration: 5000,
      });
      form.reset();
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit application. Please try again.",
        duration: 5000,
      });
      setIsSubmitting(false);
    }
  });

  function onSubmit(values: FormValues) {
    setIsSubmitting(true);
    applicationMutation.mutate(values);
  }

  return (
    <section id="apply" className="py-20 bg-[#171717] relative overflow-hidden">
      {/* Decorative blurred circles */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <div className="absolute top-0 left-0 w-64 h-64 rounded-full bg-[#FFD700] blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-80 h-80 rounded-full bg-[#20B2AA] blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block h-1 w-20 bg-[#20B2AA] mb-6 mx-auto"></span>
          <h2 className="font-montserrat font-bold text-3xl md:text-5xl text-white mb-6">
            {t('apply.title')}
          </h2>
          <p className="text-lg text-[#E5E5E5] mb-10">
            {t('apply.description')}
          </p>
          
          <div className="bg-virtus-black bg-opacity-50 p-8 md:p-10 rounded-2xl border border-[#FFD700] border-opacity-20 max-w-2xl mx-auto">
            <h3 className="font-montserrat font-bold text-2xl text-white mb-6">
              {t('apply.formTitle')}
            </h3>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('apply.fullName')}</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            className="bg-virtus-black border border-[#FFD700] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('apply.email')}</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="email" 
                            className="bg-virtus-black border border-[#FFD700] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="platform"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('apply.platform')}</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-virtus-black border border-[#FFD700] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]">
                            <SelectValue placeholder={t('apply.selectPlatform')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-[#171717] border border-[#FFD700] border-opacity-30">
                          <SelectItem value="twitch">{t('apply.options.twitch')}</SelectItem>
                          <SelectItem value="youtube">{t('apply.options.youtube')}</SelectItem>
                          <SelectItem value="tiktok">{t('apply.options.tiktok')}</SelectItem>
                          <SelectItem value="instagram">{t('apply.options.instagram')}</SelectItem>
                          <SelectItem value="other">{t('apply.options.other')}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="channelUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('apply.channelUrl')}</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="url" 
                          className="bg-virtus-black border border-[#FFD700] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('apply.aboutContent')}</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          rows={4} 
                          className="bg-virtus-black border border-[#FFD700] border-opacity-30 rounded-lg text-white focus:border-[#20B2AA]" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="pt-2">
                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full font-poppins font-medium py-3 px-8 bg-gradient-to-r from-[#FFD700] to-[#B8860B] text-virtus-black rounded-lg shadow-lg hover:from-[#B8860B] hover:to-[#FFD700] transition duration-300"
                  >
                    {isSubmitting ? "Submitting..." : t('apply.submitButton')}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JoinCTA;
