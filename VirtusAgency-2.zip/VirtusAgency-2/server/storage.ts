import { 
  users, 
  type User, 
  type InsertUser,
  creatorApplications,
  type CreatorApplication,
  type InsertCreatorApplication,
  contactMessages,
  type ContactMessage,
  type InsertContactMessage,
  newsletterSubscriptions,
  type NewsletterSubscription,
  type InsertNewsletterSubscription,
  creators,
  type Creator
} from "@shared/schema";

// Expanded storage interface with all the CRUD methods needed
export interface IStorage {
  // User methods (keeping original ones)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Creator application methods
  createCreatorApplication(application: InsertCreatorApplication): Promise<CreatorApplication>;
  getCreatorApplications(): Promise<CreatorApplication[]>;

  // Contact message methods
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;

  // Newsletter subscription methods
  createNewsletterSubscription(subscription: InsertNewsletterSubscription): Promise<NewsletterSubscription>;
  getNewsletterSubscriptions(): Promise<NewsletterSubscription[]>;
  
  // Creators methods (for display on the website)
  getCreators(): Promise<Creator[]>;
  getCreatorById(id: number): Promise<Creator | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private creatorApplications: Map<number, CreatorApplication>;
  private contactMessages: Map<number, ContactMessage>;
  private newsletterSubscriptions: Map<number, NewsletterSubscription>;
  private creators: Map<number, Creator>;
  
  private currentUserId: number;
  private currentApplicationId: number;
  private currentMessageId: number;
  private currentSubscriptionId: number;
  private currentCreatorId: number;

  constructor() {
    this.users = new Map();
    this.creatorApplications = new Map();
    this.contactMessages = new Map();
    this.newsletterSubscriptions = new Map();
    this.creators = new Map();
    
    this.currentUserId = 1;
    this.currentApplicationId = 1;
    this.currentMessageId = 1;
    this.currentSubscriptionId = 1;
    this.currentCreatorId = 1;

    // Add some sample creators for display
    this.createSampleCreators();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Creator application methods
  async createCreatorApplication(insertApplication: InsertCreatorApplication): Promise<CreatorApplication> {
    const id = this.currentApplicationId++;
    const createdAt = new Date();
    const application: CreatorApplication = { ...insertApplication, id, createdAt };
    this.creatorApplications.set(id, application);
    return application;
  }

  async getCreatorApplications(): Promise<CreatorApplication[]> {
    return Array.from(this.creatorApplications.values());
  }

  // Contact message methods
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentMessageId++;
    const createdAt = new Date();
    const message: ContactMessage = { ...insertMessage, id, createdAt };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }

  // Newsletter subscription methods
  async createNewsletterSubscription(insertSubscription: InsertNewsletterSubscription): Promise<NewsletterSubscription> {
    // Check if email already exists
    const existingSubscription = Array.from(this.newsletterSubscriptions.values()).find(
      (sub) => sub.email === insertSubscription.email
    );
    
    if (existingSubscription) {
      return existingSubscription;
    }
    
    const id = this.currentSubscriptionId++;
    const createdAt = new Date();
    const subscription: NewsletterSubscription = { ...insertSubscription, id, createdAt };
    this.newsletterSubscriptions.set(id, subscription);
    return subscription;
  }

  async getNewsletterSubscriptions(): Promise<NewsletterSubscription[]> {
    return Array.from(this.newsletterSubscriptions.values());
  }

  // Creator methods for display
  async getCreators(): Promise<Creator[]> {
    return Array.from(this.creators.values());
  }

  async getCreatorById(id: number): Promise<Creator | undefined> {
    return this.creators.get(id);
  }

  // Helper method to initialize sample creators
  private createSampleCreators() {
    const sampleCreators: Creator[] = [
      {
        id: this.currentCreatorId++,
        name: "GamerPro99",
        specialty: "FPS & Battle Royale Specialist",
        followers: 245000,
        views: 1200000,
        platforms: JSON.stringify(["twitch", "youtube", "instagram"]),
        imageUrl: "https://images.unsplash.com/photo-1580171401298-15e2b9531b0f",
        isLive: true
      },
      {
        id: this.currentCreatorId++,
        name: "StreamQueen",
        specialty: "IRL & Just Chatting Streamer",
        followers: 189000,
        views: 890000,
        platforms: JSON.stringify(["twitch", "tiktok", "instagram"]),
        imageUrl: "https://images.unsplash.com/photo-1615568057392-8f933710de76",
        isLive: false
      },
      {
        id: this.currentCreatorId++,
        name: "TechWizard",
        specialty: "Tech Reviews & Programming",
        followers: 312000,
        views: 1500000,
        platforms: JSON.stringify(["youtube", "twitter", "discord"]),
        imageUrl: "https://images.unsplash.com/photo-1599058917765-a780eda07a3e",
        isLive: true
      },
      {
        id: this.currentCreatorId++,
        name: "MusicMaestro",
        specialty: "Music Production & DJ Sets",
        followers: 178000,
        views: 750000,
        platforms: JSON.stringify(["twitch", "spotify", "soundcloud"]),
        imageUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420",
        isLive: false
      }
    ];

    sampleCreators.forEach(creator => {
      this.creators.set(creator.id, creator);
    });
  }
}

export const storage = new MemStorage();
